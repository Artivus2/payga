from pydantic import BaseModel, HttpUrl
from hashlib import sha256
import mysql
from mysql.connector import errorcode
import logging
import time
import mysql.connector as cpy



