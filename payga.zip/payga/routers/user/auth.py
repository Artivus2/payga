# from pydantic import EmailStr
# from jose import jwt
# from datetime import datetime, timedelta, timezone
# from payga_old.routers.auth.schemas import EmailModel
# from payga_old.routers.auth.utils import verify_password
# from payga_old.config import settings
# from payga_old.routers.auth.dao import UsersDAO
# #from payga_old.dao.session_maker import SessionDep
#
#
# def create_access_token(data: dict) -> str:
#     # to_encode = data.copy()
#     # expire = datetime.now(timezone.utc) + timedelta(days=30)
#     # to_encode.update({"exp": expire})
#     # encode_jwt = jwt.encode(to_encode, settings.SECRET_KEY, algorithm=settings.ALGORITHM)
#     # return encode_jwt
#     pass
#
#
# async def authenticate_user(email: EmailStr, password: str):
#     # user = await UsersDAO.find_one_or_none(session=session, filters=EmailModel(email=email))
#     # if not user or verify_password(plain_password=password, hashed_password=user.password) is False:
#     #     return None
#     # return user
#     pass
