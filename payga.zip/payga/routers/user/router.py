import json
from typing import List
import requests
from fastapi import APIRouter, Response, Depends, HTTPException, Depends, Header, Query
import config
import payga.routers.user.models as user_models
#from payga_old.routers.user.dependencies import get_current_user, get_current_admin_user
# from payga.routers.user.models import User
# from payga_old.exceptions import UserAlreadyExistsException, IncorrectEmailOrPasswordException
# from payga_old.routers.auth.auth import authenticate_user, create_access_token
# from payga_old.routers.auth.dao import UsersDAO
# from payga_old.routers.auth.schemas import SUserRegister, SUserAuth, EmailModel, SUserAddDB, SUserInfo
# from sqlalchemy.ext.asyncio import AsyncSession
#from payga.dao.session_maker import TransactionSessionDep, SessionDep
from payga.routers.user.utils import hash_from_yii2
from payga.routers.user.utils import create_random_key
from routers.user import models

router = APIRouter(prefix='/api/v1/user', tags=['User'])


@router.post("/login")
async def login(request: user_models.Login):
    """
    email
    password
    :return:
    {token}
    """
    api_url = f'{config.BASE_URL}/api/user/login'
    headers = {
        'Content-Type': 'application/json'
    }
    payload = {
        'email': request.email,  # req
        'password': request.password  # req
    }
    response = requests.post(api_url, headers=headers, data=json.dumps(payload))
    if response.status_code != 200:
        raise HTTPException(status_code=response.status_code, detail=response.json())
    return response.json()


@router.post("/code")
async def code(request: user_models.Code):
    """
    запрос токена авторизации
    :param request: email, password, code
    :return:
    {access_token}
    """
    api_url = f'{config.BASE_URL}/api/user/code'
    headers = {
        'Content-Type': 'application/json'
    }
    payload = {
        'email': request.email,  # req
        'password': request.password,  # req
        'code': request.code  # req
    }
    print(payload)
    response = requests.post(api_url, headers=headers, data=json.dumps(payload))
    if response.status_code != 200:
        raise HTTPException(status_code=response.status_code, detail=response.json())
    print(response.json())
    return response.json()


@router.post("/logout")
async def logout(request: user_models.Logout):
    """
    Логаут
    :param request:
    token
    :return:
    """
    api_url = f'{config.BASE_URL}/api/user/logout'
    headers = {
        'Content-Type': 'application/json'
    }
    payload = {
        'token': request.token
    }
    response = requests.post(api_url, headers=headers, data=json.dumps(payload))
    if response.status_code != 200:
        raise HTTPException(status_code=response.status_code, detail=response.json())
    return response.json()


@router.post("/register-request")
async def register_request(request: user_models.User):
    """
    login: Логин,
    email: емаил,
    telegram: телеграм
    affiliate: реф,
    password: пароль,
    :param request:
    :return:
    {comment возращает ссылку на регистрацию после подтверждения администратора, отправляет на почту пользователю}
    """
    hashed_password = await hash_from_yii2(request.password)
    payload = {
        'email': request.email,
        'login': request.login,
        'telegram': request.telegram,
        'affiliate_invitation_id': request.affiliate_invitation_id,
        'password': hashed_password['password']
    }
    #print(payload)
    if await user_models.User.insert_new_user(**payload):
        return {'message': f'Вы успешно зарегистрированы!'}


@router.post("/confirm-request")
async def confirm_request(request: user_models.RegisterRequest):
    """
    Подтверждение регистрации админом
    Args: Подтверждение
        request: Логин

    Returns:
        Успешно

    """
    link = await user_models.RegisterRequest.send_link_to_user(request.id)
    # send link todo

@router.post("/enable-2fa")
async def enable_2fa(request: user_models.Twofa):
    pass

@router.post("/disable-2fa")
async def disable_2fa(request: user_models.Twofa):
    pass

@router.post("/change-password")
async def change_password(request: user_models.User):
    pass


