# from passlib.context import CryptContext
#
# pwd_context = CryptContext(schemes=["bcrypt"], deprecated="auto")
# def get_password_hash(password: str) -> str:
#     return pwd_context.hash(password)
#
#
# def verify_password(plain_password: str, hashed_password: str) -> bool:
#     return pwd_context.verify(plain_password, hashed_password)
import requests
from fastapi import HTTPException
import config


async def hash_from_yii2(password):
    """
    получить хешкод пароля из yii2
    :param password:
    :return:
    """
    api_url = f'{config.BASE_URL}/api/user/get-password'
    headers = {
        'Content-Type': 'application/json'
    }
    payload = {
        'password': password  # req
    }
    response = requests.post(api_url, headers=headers, data=json.dumps(payload))
    if response.status_code != 200:
        raise HTTPException(status_code=response.status_code, detail=response.json())
    print(response.json())
    return response.json()
