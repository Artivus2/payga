# from payga_old.dao.base import BaseDAO
# from payga_old.routers.auth.models import User, Role
#
#
# class UsersDAO(BaseDAO):
#     model = User
#
#
# class RoleDAO(BaseDAO):
#     model = Role
