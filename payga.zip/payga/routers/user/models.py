# from sqlalchemy import text, ForeignKey
# from sqlalchemy.orm import Mapped, mapped_column, relationship
# from payga_old.dao.database import Base, str_uniq
import mysql.connector as cpy
from pydantic import BaseModel, HttpUrl
from payga.routers.user.utils import create_random_key

import config


class Role(BaseModel):
    # name: Mapped[str_uniq]
    # users: Mapped[list["User"]] = relationship(back_populates="role")

    # def __repr__(self):
    #     return f"{self.__class__.__name__}(id={self.id}, name={self.name})"
    pass


class User(BaseModel):
    login: str
    email: str
    password: str
    telegram: str
    affiliate_invitation_id: str

    async def insert_new_user(self, **payload):
        #try todo
        with cpy.connect(**config.config) as cnx:
            with cnx.cursor() as cur:
                app_id = 3 # paygreenavi
                link_gen = await create_random_key()
                data_login = "SELECT * from user where login = '" + str(payload['login']) + \
                             "' or email = '" + payload['email'] + "'"
                cur.execute(data_login)
                data = cur.fetchall()
                data_ref = "SELECT id from user where login = '" + str(payload['affiliate_invitation_id']) + "'"
                cur.execute(data_ref)
                ref_id = cur.fetchone()

                if not ref_id:
                    ref_id = 0
                    link = config.REG_URL
                else:
                    link = config.REG_URL + "/" + str(link_gen)

                if not data:
                    data_string = "INSERT INTO user (login, email, password, affiliate_invitation_id, comment, telegram, app_id) " \
                                  "VALUES ('" + str(payload['login']) + "','" + str(payload['email']) + \
                                  "','" + str(payload['password']) + "','" + str(ref_id) + "','" + str(link_gen) + "','" + str(
                        payload['telegram']) + "','" + str(app_id) + "')"
                    cur.execute(data_string)
                    cnx.commit()
                    cnx.close()
                    #print(comment)
                    return True
        return False


class Logout(BaseModel):
    token: str


class RegisterRequest(BaseModel):
    id: int
    login: str

    async def send_link_to_user(self, id, login=None):
        with cpy.connect(**config.config) as cnx:
            with cnx.cursor() as cur:
                string = "SELECT comment from user where id = '" + str(id) + \
                             "' or login = '" + str(login) + "'"
                cur.execute(string)
                data = cur.fetchone()
                if data:
                    link = config.REG_URL + "/" + data[0]
                    return {"link": link}
                cur.close()





class Login(BaseModel):
    email: str
    password: str


class Code(BaseModel):
    email: str
    password: str
    code: str


class JwtRequest(BaseModel):
    email: str
    password: str


class Twofa(BaseModel):
    code: str