# from sqlalchemy import text, ForeignKey
# from sqlalchemy.orm import Mapped, mapped_column, relationship
# from payga_old.dao.database import Base, str_uniq
import mysql.connector as cpy
from pydantic import BaseModel, HttpUrl

import config


class Role(BaseModel):
    # name: Mapped[str_uniq]
    # users: Mapped[list["User"]] = relationship(back_populates="role")

    # def __repr__(self):
    #     return f"{self.__class__.__name__}(id={self.id}, name={self.name})"
    pass


class User(BaseModel):
    first_name: str
    last_name: str
    email: str
    password: str
    role_id: str
    role: str
    telegram: str

    # def __repr__(self):
    #     return f"{self.__class__.__name__}(id={self.id})"
    def insert_new_user(self, **payload):

        with cpy.connect(**config.config) as cnx:
            with cnx.cursor() as cur:
                app_id = 3
                comment = 'https://test.greenavi.com/confirm-register?login=' + str(payload['login'])
                data_login = "SELECT * from user where login = '" + str(payload['login']) + "' or email = '" + payload[
                    'email'] + "'"
                print(data_login)
                cur.execute(data_login)
                data = cur.fetchall()
                print(data)
                if not data:
                    data_string = "INSERT INTO user (login, email, password, comment, telegram, app_id) " \
                                  "VALUES ('" + str(payload['login']) + "','" + str(payload['email']) + \
                                  "','" + str(payload['password']) + "','" + str(comment) + "','" + str(
                        payload['telegram']) \
                                  + "','" + str(app_id) + "')"
                    cur.execute(data_string)
                    cnx.commit()
                    cnx.close()
                    #print(comment)
                    return comment
                else:
                    cnx.close()
                    return "Пользователь уже существует"


class Logout(BaseModel):
    token: str


class RegisterRequest(BaseModel):
    login: str
    email: str
    telegram: str
    affiliate: str
    password: str


class Login(BaseModel):
    email: str
    password: str


class Code(BaseModel):
    email: str
    password: str
    code: str


class JwtRequest(BaseModel):
    email: str
    password: str


class Twofa(BaseModel):
    code: str