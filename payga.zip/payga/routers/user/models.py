from pydantic import BaseModel

class User(BaseModel):
    """
    api_key - ключ для АПИ
    """
    login: str
    email: str
    password: str
    telegram: str
    affiliate_invitation_id: int


class ApiKey(BaseModel):
    """
    Status: Валидный (1), Не валидный (0)
    """
    id: int
    user_id: int
    api_key: str
    api_key_expired_date: int
    status: int

class Logout(BaseModel):
    token: str


class RegisterRequest(BaseModel):
    id: int
    login: str


class Login(BaseModel):
    email: str
    password: str


class Code(BaseModel):
    email: str
    password: str
    code: str


class JwtRequest(BaseModel):
    email: str
    password: str


class Twofa(BaseModel):
    code: str

