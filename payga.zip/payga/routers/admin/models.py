from pydantic import BaseModel


class ConfirmRegister(BaseModel):
    user_id: int
    login: str
    email: str


class Status(BaseModel):
    """
    status: Активна (1), не активна (0)
    """
    id: int
    title: str


class Methods(BaseModel):
    """
    Все методы
    """
    id: int
    title: str
    status: int


class Pages(BaseModel):
    """
    страницы
    """
    id: int
    title: str
    status: int


class Role(BaseModel):
    """
    Группы пользователей (Трейдеры, Магазины, Оператор, администратор)
    """
    id: int
    title: str
    pages: int
    status: int


class AuthRoles(BaseModel):
    """
    привязка к группе методов ролей user страниц
    """
    id: int | None
    user_id: int | None
    role_id: int | None
    method_id: int | None
    page_id: int | None
    status: int | None
    allowed: bool | None






