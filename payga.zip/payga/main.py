import asyncio
import uvicorn
from fastapi import FastAPI
from fastapi.middleware.cors import CORSMiddleware
from routers.orders.router import router as router_orders
from routers.user.router import router as router_user
from routers.admin.router import router as router_admin
from routers.actives.router import router as router_actives
from routers.mains.router import router as router_mains
from routers.roles.router import router as router_roles
from routers.stats.router import router as router_stats

app = FastAPI()


# Добавляем middleware для CORS
app.add_middleware(
    CORSMiddleware,
    allow_origins=["*"],  # Разрешаем все источники
    allow_credentials=True,
    allow_methods=["*"],  # Разрешаем все методы
    allow_headers=["*"],  # Разрешаем все заголовки
)

@app.get("/")
async def route():
    return {
        "message": "Сайт находится в разработке!"
    }
app.include_router(router_user)
app.include_router(router_orders)
app.include_router(router_admin)
app.include_router(router_actives)
app.include_router(router_mains)
app.include_router(router_roles)
app.include_router(router_stats)
# и еще todo


async def main():
    config = uvicorn.Config("main:app", port=5001, log_level="info", reload=True)
    server = uvicorn.Server(config)
    await server.serve()


if __name__ == "__main__":
    asyncio.run(main())
