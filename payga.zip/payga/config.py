BASE_URL = 'http://localhost:8080'
REG_URL = 'https://test.greenavi.com'
config = {
            'user': 'greenavi_user',
            'password': 'tb7x3Er5PQ',
            'host': '127.0.0.1',
            'database': 'greenavi_app',
            'raise_on_warnings': True
        }