BASE_URL = 'http://localhost'
config = {
            'user': 'greenavi_user',
            'password': 'tb7x3Er5PQ',
            'host': '127.0.0.1',
            'database': 'greenavi_app',
            'raise_on_warnings': True
        }