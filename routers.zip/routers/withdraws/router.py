from fastapi import APIRouter
import routers.withdraws.models as withdraws_models


router = APIRouter(prefix='/api/v1/withdraws', tags=['Вывод средств'])


@router.post("/check-balance")
async def get_stats(request: withdraws_models.Withdraws):
    """
    получить баланс для вывода средств
    :param request:
    :return:
    """
    pass


@router.post("/balance-out")
async def get_stats(request: withdraws_models.Withdraws):
    """
    создать заявку на вывод средств (в разработке)
    :param request:
    :return:
    """
    pass


